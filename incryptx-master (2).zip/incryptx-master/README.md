# Incrypt-[X]

Define a description of the CTF in `templates/index.html`.

Install requirements `pip install -r requirements.txt`

Define the set of challenges in `chals.py`.

Run `python chals.py` to setup the database.

Run `python run.py` and you are up.
